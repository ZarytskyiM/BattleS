
#ifndef CHECK_WIN_HPP_
#define CHECK_WIN_HPP_

#include "constants.hpp"
#include "Point.hpp"


template<typename T>
bool checkWin(const T& desk, int player) {
    
    int en = 3 - player;
    int blasted = 0;
    for (int i = 0; i < desk.getLength(); i++) {
        for (int x = 0; x < desk.getWidth(); x++) {
            Point pt(i, x);
            if (desk.getVisibility(pt, en)) {
                if (desk.getCellState(pt, en)) {
                    blasted++;
                }
            }
        }
    }
    return (blasted == SHIP_ITEMS);
}

#endif
