
#ifndef CELL_HPP_
#define CELL_HPP_


struct Cell {
  
    bool is_ship;

 
    bool is_sunken_ship;

  
    bool is_visible;
};

#endif
