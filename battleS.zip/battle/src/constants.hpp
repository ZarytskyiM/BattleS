
#ifndef CONSTANTS_HPP_
#define CONSTANTS_HPP_


const int MOVE_WAIT = 3000;


const int DEFAULT_WIDTH = 13;


const int MIN_WIDTH = 11;


const int MAX_WIDTH = 16;


const int DEFAULT_LENGTH = 13;


const int MIN_LENGTH = 11;


const int MAX_LENGTH = 16;


const int MAX_SHIP_LENGTH = 5;


const int MIN_SHIP_LENGTH = 2;


const int SHIP_ITEMS = 30;

#endif
