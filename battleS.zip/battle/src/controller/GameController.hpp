
#ifndef GAME_CONTROLLER_HPP_
#define GAME_CONTROLLER_HPP_

#include "GameDesk.hpp"


class GameController {
public:
   
    static GameController* make(GameDesk* desk);

   
    void initialStateOfBoard();

 
    void makeMove(int player_number, const Point& point);

  
    void setShip(int player_number, const Ship& ship);

    

private:
    GameDesk* desk_;

    GameController();

    bool checkBurst(const Ship& ship,
                    int player_number) const;
};

#endif
