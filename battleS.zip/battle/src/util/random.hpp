
#ifndef RANDOM_HPP_
#define RANDOM_HPP_

#include <vector>
#include <cstdlib>


unsigned int random(unsigned int end);


unsigned int randomWithUnequalChances(std::vector<int>&
                                      chances);

#endif
