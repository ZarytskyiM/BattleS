

#ifndef POINT_HPP_
#define POINT_HPP_


struct Point {
    
    Point(int col, int row);

 
    int col;

 
    int row;
};


struct Ship {
   
    Ship(Point p1, Point p2);

    
    Point p1;

    
    Point p2;

   
    bool isHorizontal() const;
};

#endif
