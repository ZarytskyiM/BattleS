

#ifndef GAME_DESK_PROXY_HPP_
#define GAME_DESK_PROXY_HPP_

#include "GameDesk.hpp"


class GameDeskProxy {
public:
   
    static GameDeskProxy* make(const GameDesk* desk,
                               int player_number);

    
    bool getCellState(const Point& point,
                      int player_number) const;

    
    bool getFlooding(const Point& point,
                     int player_number) const;

    
    bool getVisibility(const Point& point,
                       int player_number) const;

    int getWidth() const;

   
    int getLength() const;

   
    int getPlayerNumber() const;

private:
    const GameDesk* desk_;
    int player_number_;

    GameDeskProxy();
};

#endif
