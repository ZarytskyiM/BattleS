

#ifndef PLACE_SHIPS_HPP_
#define PLACE_SHIPS_HPP_

#include "GameController.hpp"


void placeShips(GameController& controller,
                const GameDesk& desk,
                int player_number);

#endif
