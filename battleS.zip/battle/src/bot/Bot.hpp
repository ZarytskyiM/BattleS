

#ifndef BOT_HPP_
#define BOT_HPP_

#include <vector>

#include "GameDeskProxy.hpp"


class Bot {
public:
   
    static Bot* make(const GameDeskProxy* desk,
                     int bot_number);

    Point getIndex() const;

private:
    const GameDeskProxy* desk_;

    int bot_number_;

   
    bool checkCoordinate(const Point& point) const;

 
    bool checkNeighboringCells(const Point& point) const;

   
    Point randomRationalCell() const;

   
    bool visibleOrSunksNeighbor(const Point& point) const;

    std::vector<int> evaluateCells(const std::vector
                                   <Point>& cells) const;

    int evaluateCell(const Point& point) const;

   
    Point neighboringBurningCell(const Point& point) const;

    Point theBestCell(const std::vector<Point>&
                      cells) const;

    Bot();
};

#endif
