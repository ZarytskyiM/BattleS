

#ifndef GAME_DESK_HPP_
#define GAME_DESK_HPP_

#include <vector>

#include "constants.hpp"
#include "Exception.hpp"
#include "Point.hpp"
#include "Cell.hpp"


class GameDesk {
public:
   
    static GameDesk* make(int width, int length);

   
    void setCellState(const Point& point, bool state,
                      int player_number);

   
    bool getCellState(const Point& point,
                      int player_number) const;

    void setFlooding(const Point& point, bool is_sunken,
                     int player_number);

    bool getFlooding(const Point& point,
                     int player_number) const;

   
    void setVisibility(const Point& point, bool is_visible,
                       int player_number);

   
    bool getVisibility(const Point& point,
                       int player_number) const;

   
    int getWidth() const;

  
    int getLength() const;

private:
  
    std::vector<Cell> player1_desk_;

  
    std::vector<Cell> player2_desk_;

    int width_;
    int length_;

    GameDesk();
};

#endif
