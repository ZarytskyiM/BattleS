
#include "Point.hpp"

Point::Point(int col, int row):
    col(col), row(row) {
}

Ship::Ship(Point p1, Point p2):
    p1(p1), p2(p2) {
}

bool Ship::isHorizontal() const {
    if (p1.col == p2.col) {
        return true;
    } else {
        return false;
    }
}
