

#ifndef EXCEPTION_HPP_
#define EXCEPTION_HPP_

#include <string>
#include <exception>


class Exception: public std::exception {
public:
   
    Exception(const std::string& message);


    ~Exception() throw();


    const char* what() const throw();

private:
    std::string message_;
};

#endif
