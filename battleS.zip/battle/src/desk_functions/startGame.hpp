

#ifndef START_GAME_HPP_
#define START_GAME_HPP_

#include "Game.hpp"


QSharedPointer<Game> startGame(QObject* window,
                               int width, int length);

#endif
